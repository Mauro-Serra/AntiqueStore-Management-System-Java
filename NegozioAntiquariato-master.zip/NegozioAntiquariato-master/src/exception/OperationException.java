package exception;

public class OperationException extends Exception {
	public OperationException() {}
	
	public OperationException(String msg) {
		super(msg);
	}
}
