import boundary.BoundaryLogin;

public class Main {
    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(() -> {
            new BoundaryLogin().setVisible(true);
        });
    }
}
